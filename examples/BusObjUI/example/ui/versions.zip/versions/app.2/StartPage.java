/*
    Copyright (c) 1996-2002 Ariba, Inc.
    All rights reserved. Patents pending.

    $Id: //ariba/platform/ui/demoshell/example/ui/versions/app.2/StartPage.java#1 $

    Responsible: craigf
*/
package example.ui.app;

import ariba.ui.aribaweb.core.AWComponent;
import example.ui.busobj.Member;
import example.ui.busobj.Project;
import example.ui.busobj.Deal;

public final class StartPage extends AWComponent
{
    public Project _project = Project.sharedInstance();
    public Deal _currentDeal;

    public void deleteDeal ()
    {
        _project.removeDeal(_currentDeal);
    }

    public void addNewDeal ()
    {
        _project.addNewDeal();
    }

    public AWComponent submit ()
    {
        // in real app, would go somewhere if hasNoErrors()==true
        errorManager().checkErrorsAndEnableDisplay();
        return null;
    }

    public boolean isStateless () {
        return false;
    }
}
