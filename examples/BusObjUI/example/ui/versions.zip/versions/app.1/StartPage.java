/*
    Copyright (c) 1996-2002 Ariba, Inc.
    All rights reserved. Patents pending.

    $Id: //ariba/platform/ui/demoshell/example/ui/versions/app.1/StartPage.java#1 $

    Responsible: craigf
*/
package example.ui.app;

import ariba.ui.aribaweb.core.AWComponent;
import example.ui.busobj.Member;
import example.ui.busobj.Project;
import example.ui.busobj.Deal;

public final class StartPage extends AWComponent
{
    public Project _project = Project.sharedInstance();
    public int goodSubmissions;

    public AWComponent submit ()
    {
        // in real app, would go somewhere if hasNoErrors()==true
        if (errorManager().checkErrorsAndEnableDisplay()) goodSubmissions++;
        return null;
    }

    public boolean isStateless () {
        return false;
    }
}
