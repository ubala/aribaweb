/*
    Copyright (c) 1996-2002 Ariba, Inc.
    All rights reserved. Patents pending.

    $Id: //ariba/platform/ui/demoshell/example/ui/versions/app.5/ToManyEditPage.java#1 $

    Responsible: craigf
*/
package example.ui.app;

import ariba.ui.aribaweb.core.AWComponent;
import ariba.util.fieldvalue.FieldValue;

public class ToManyEditPage extends AWComponent
{
    public Object _list;        // AWOrderedList
    public Object _selection;   // AWOrderedList
    public Object _currentItem;
    public int _currentIndex;
    protected String _displayKey;
    CallBack _callback;

    public void init (Object list, Object selection, String displayKey, CallBack callback)
    {
        _callback = callback;
        _list = list;
        _selection = selection;
        _displayKey = displayKey;
    }

    public Object getSelection ()
    {
        return _selection;
    }

    public AWComponent okayAction ()
    {
        return _callback.editCompleted(this);
    }

    public AWComponent cancelAction ()
    {
        return _callback.editCancelled(this);
    }

    public String currentItemString ()
    {
        return (String)FieldValue.getFieldValue(_currentItem, _displayKey);
    }

    public static abstract class CallBack {
        abstract AWComponent editCompleted (ToManyEditPage target);
        abstract AWComponent editCancelled (ToManyEditPage target);
    }


}
