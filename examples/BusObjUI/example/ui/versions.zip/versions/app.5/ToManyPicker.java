/*
    Copyright (c) 1996-2002 Ariba, Inc.
    All rights reserved. Patents pending.

    $Id: //ariba/platform/ui/demoshell/example/ui/versions/app.5/ToManyPicker.java#1 $

    Responsible: craigf
*/
package example.ui.app;

import ariba.util.fieldvalue.FieldValue;
import ariba.ui.aribaweb.core.AWComponent;

public final class ToManyPicker extends AWComponent
{
    public Object _currentItem;

    public String currentItemString ()
    {
        return (String)FieldValue.getFieldValue(_currentItem, stringValueForBinding("displayKey"));
    }

    public AWComponent edit ()
    {
        ToManyEditPage page = (ToManyEditPage)pageWithName(ToManyEditPage.class.getName());
        page.init(valueForBinding("list"), valueForBinding("selection"), stringValueForBinding("displayKey"),
                new ToManyEditPage.CallBack() {
                    AWComponent editCompleted (ToManyEditPage result) {
                        setValueForBinding(result.getSelection(), "selection");
                        return pageComponent();
                    }
                    AWComponent editCancelled (ToManyEditPage result) {
                        return pageComponent();
                    }
                });
        return page;
    }

    public boolean isStateless ()
    {
        // we stay stateful so our inner class can be an action handler for the
        // picker sub-page (and retain its pointer to our parent component)
        return false;
    }
}
