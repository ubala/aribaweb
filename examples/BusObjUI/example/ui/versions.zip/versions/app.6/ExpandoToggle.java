/*
    Copyright (c) 1996-2002 Ariba, Inc.
    All rights reserved. Patents pending.

    $Id: //ariba/platform/ui/demoshell/example/ui/versions/app.6/ExpandoToggle.java#1 $

    Responsible: craigf
*/
package example.ui.app;

import ariba.ui.aribaweb.core.AWComponent;
import ariba.ui.aribaweb.core.AWNavigation;

public final class ExpandoToggle extends AWComponent
{
    public boolean _expanded = false;

    public AWComponent toggle ()
    {
        AWComponent r;      // if we're about to hide, make sure that that's okay
        if (_expanded && ((r = AWNavigation.requestNavigation(this, AWNavigation.Hide)) != null) ) {
            return r;
        }
        _expanded = !_expanded;
        return null;
    }

    public boolean isStateless () {
        return false;
    }
}
